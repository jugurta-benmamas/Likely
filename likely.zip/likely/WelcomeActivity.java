package fr.jugurta.likely;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class WelcomeActivity extends AppCompatActivity {

    private TextView welcome, toActivityMain;
    private ImageView welcome_logo;
    private ProgressBar progressbar;

    private  final int Splash_Screen_TimeOut = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
                finish();
            }
        }, Splash_Screen_TimeOut);

        welcome_logo = (ImageView) findViewById(R.id.welcome_logo);
        welcome = (TextView) findViewById(R.id.welcome);
        toActivityMain = (TextView) findViewById(R.id.toMainActivity);
        progressbar = (ProgressBar) findViewById(R.id.progressbar);

        Animation splashanim = AnimationUtils.loadAnimation(this,R.anim.splash_animation);
        welcome_logo.startAnimation(splashanim);
        welcome.startAnimation(splashanim);
        toActivityMain.startAnimation(splashanim);
        progressbar.startAnimation(splashanim);

    }
}