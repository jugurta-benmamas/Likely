package fr.jugurta.likely;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import fr.jugurta.likely.LoginSignup.StartUpScreen;

public class SplashScreenActivity extends AppCompatActivity {

    private ImageView logo;
    private TextView text;
    private  final int Splash_Screen_TimeOut = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                    Intent intent = new Intent(getApplicationContext(), StartUpScreen.class);
                    startActivity(intent);
                    finish();
                overridePendingTransition(0,0);
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            }
        }, Splash_Screen_TimeOut);

        logo = (ImageView) findViewById(R.id.splash_logo);

        text = (TextView) findViewById(R.id.splash_text);


        Animation splashanim = AnimationUtils.loadAnimation(this,R.anim.splash_animation);
        logo.startAnimation(splashanim);
        text.startAnimation(splashanim);

    }
}