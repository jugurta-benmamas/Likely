package fr.jugurta.likely;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.hbb20.CountryCodePicker;

import fr.jugurta.likely.LoginSignup.RegisterUser;
import fr.jugurta.likely.LoginSignup.RegisterUser2nd;

public class Choice_Interet extends AppCompatActivity implements View.OnClickListener {

    private ImageView back;
    private ImageView animaux, art, automobile, cosmetique, film, highTech, jeuxVideo, litterature, mode, moto, musique, nourriture, politique, sante, serie, sport, voyage;
    private FirebaseAuth mAuth;

    ScrollView scrollView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice__interet);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        scrollView = findViewById(R.id.scrollView_register2);


        back = (ImageView) findViewById(R.id.back_button);
        back.setOnClickListener(this);


        animaux = (ImageView) findViewById(R.id.animaux);
        animaux.setOnClickListener(this);

        art = (ImageView) findViewById(R.id.art);
        art.setOnClickListener(this);

        automobile = (ImageView) findViewById(R.id.automobile);
        automobile.setOnClickListener(this);

        cosmetique = (ImageView) findViewById(R.id.cosmetique);
        cosmetique.setOnClickListener(this);

        film = (ImageView) findViewById(R.id.film);
        film.setOnClickListener(this);

        highTech = (ImageView) findViewById(R.id.highTech);
        highTech.setOnClickListener(this);

        jeuxVideo = (ImageView) findViewById(R.id.jeuxVideo);
        jeuxVideo.setOnClickListener(this);

        litterature = (ImageView) findViewById(R.id.litterature);
        litterature.setOnClickListener(this);

        mode = (ImageView) findViewById(R.id.mode);
        mode.setOnClickListener(this);

        moto = (ImageView) findViewById(R.id.moto);
        moto.setOnClickListener(this);

        musique = (ImageView) findViewById(R.id.musique);
        musique.setOnClickListener(this);

        nourriture = (ImageView) findViewById(R.id.nourriture);
        nourriture.setOnClickListener(this);

        politique = (ImageView) findViewById(R.id.politique);
        politique.setOnClickListener(this);

        sante = (ImageView) findViewById(R.id.sante);
        sante.setOnClickListener(this);

        serie = (ImageView) findViewById(R.id.serie);
        serie.setOnClickListener(this);

        sport = (ImageView) findViewById(R.id.sport);
        sport.setOnClickListener(this);

        voyage = (ImageView) findViewById(R.id.voyage);
        voyage.setOnClickListener(this);


    }





    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_button:
                startActivity(new Intent(this, RegisterUser2nd.class));
                break;
        }


    }
}