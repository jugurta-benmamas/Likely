package fr.jugurta.likely.LoginSignup;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.android.material.textfield.TextInputLayout;
import com.hbb20.CountryCodePicker;

import java.util.Calendar;

import fr.jugurta.likely.Choice_Interet;
import fr.jugurta.likely.Phone;
import fr.jugurta.likely.R;
import fr.jugurta.likely.VerifyOTP;

public class RegisterUser2nd extends AppCompatActivity implements View.OnClickListener {

    private Button next;
    private ImageView back;
    RadioGroup radioGroup;
    RadioButton selectedGender;
    DatePicker datePicker;
    ScrollView scrollView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register_user2nd);


        scrollView = findViewById(R.id.scrollView_register2);


        next = (Button) findViewById(R.id.next_bouton);
        next.setOnClickListener(this);


        back = (ImageView) findViewById(R.id.back_btn_);
        back.setOnClickListener(this);

        radioGroup = findViewById(R.id.radio_group);
        datePicker = findViewById(R.id.age_picker);



    }
    public void callNextRegister3nd (View view){
        if (!validateGender() | !validateAge()) {
            return;
        }

        selectedGender = findViewById(radioGroup.getCheckedRadioButtonId());
        String _gender = selectedGender.getText().toString();

        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth();
        int year = datePicker.getYear();

        String _date = day+"/"+month+"/"+year;

        Intent intent = new Intent(getApplicationContext(), Phone.class);
        Pair[] pairs = new Pair[2];
        pairs [0] = new Pair<View, String>(back, "transition_back_arrow_btn");
        pairs [1] = new Pair<View, String>(next, "transition_next_btn");
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP){
            ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(RegisterUser2nd.this, pairs);
            startActivity(intent, options.toBundle());
        }else {
            startActivity(intent);
        }

    }
    private boolean validateGender(){
        if(radioGroup.getCheckedRadioButtonId()==-1){
            Toast.makeText(this, "Veuillez choisir un sexe", Toast.LENGTH_SHORT).show();
            return false;
        }else{
            return true;
        }

    }

    private boolean validateAge(){
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int userAge = datePicker.getYear();
        int isAgeValid = currentYear - userAge;

        if(isAgeValid <14){
            Toast.makeText(this, "Vous êtes trop jeune !", Toast.LENGTH_SHORT).show();
            return false;
        }else {
            return true;
        }
    }

    private boolean validatePhoneNumber() {
        return false;
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back_btn_:
                startActivity(new Intent(this, RegisterUser.class));
                break;
        }

    }


}