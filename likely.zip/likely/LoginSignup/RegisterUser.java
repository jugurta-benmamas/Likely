
package fr.jugurta.likely.LoginSignup;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;


import fr.jugurta.likely.Phone;
import fr.jugurta.likely.R;
import fr.jugurta.likely.VerifyOTP;

public class RegisterUser extends AppCompatActivity implements View.OnClickListener {

    private TextView banner, registerUser;
    private TextView connexion;
    private ImageView back;
    private ProgressBar progressBar;
    ScrollView scrollView;


    TextInputLayout fullName, username, email, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_register_user);
        FirebaseDatabase database = FirebaseDatabase.getInstance();

        progressBar = (ProgressBar) findViewById(R.id.progress_bar);
        scrollView = findViewById(R.id.ScrollViewRegister);



        banner = (TextView) findViewById(R.id.banner_register);
        banner.setOnClickListener(this);

        back = (ImageView) findViewById(R.id.back_btn);
        back.setOnClickListener(this);

        registerUser = (Button) findViewById(R.id.next_btn);
        registerUser.setOnClickListener(this);

        fullName = findViewById(R.id.fullname);
        username = findViewById(R.id.userName);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);


        connexion = (TextView) findViewById(R.id.connexion_btn);
        connexion.setOnClickListener(this);


        }
    public void callNextRegister2nd(View view){
        if(!validateFullName() | !validateUserName() | !validateEmail() | !validatePassword()){
            return;
        }
        Intent intent = new Intent(getApplicationContext(), RegisterUser2nd.class);
        Pair[] pairs = new Pair[2];
        pairs [0] = new Pair<View, String>(back, "transition_back_arrow_btn");
        pairs [1] = new Pair<View, String>(registerUser, "transition_next_btn");
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP){
            ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(RegisterUser.this, pairs);
            startActivity(intent, options.toBundle());
        }else {
            startActivity(intent);
        }

    }


    private boolean validateFullName() {
        String val = fullName.getEditText().getText().toString().trim();

        if (val.isEmpty()) {
            fullName.setError("Veuillez indiquer votre nom et prénom !");
            return false;
        } else {
            fullName.setError(null);
            fullName.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateUserName() {
        String val = username.getEditText().getText().toString().trim();
        String checkspaces = "\\A\\w{1,20}\\z";

        if (val.isEmpty()) {
            username.setError("Veuillez indiquer une adresse e-mail !");
            return false;
        } else if(val.length()>20){
            username.setError("Ce nom d'utilisateur est trop long !");
            return false;
        }
        else if(!val.matches(checkspaces)){
            username.setError("Les espaces ne sont pas autorisés !");
            return false;
        } else {
            username.setError(null);
            username.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validateEmail() {
        String val = email.getEditText().getText().toString().trim();
        String checkEmail = "[a-zA-Z0-9]+@[a-z]+\\.+[a-z]+";

        if (val.isEmpty()) {
            email.setError("Veuillez indiquer une adresse e-mail !");
            return false;
        } else if(!val.matches(checkEmail)){
            email.setError("Adresse e-mail invalide !");
            return false;
        } else {
            email.setError(null);
            email.setErrorEnabled(false);
            return true;
        }
    }

    private boolean validatePassword() {
        String val = password.getEditText().getText().toString().trim();
        String checkPassword = "^" +
                "(?=.*[a-zA-Z])" +
                "(?=.*[0-9])" +
                "(?=\\S+$)" +
                ".{6,}" +
                "$";

        if (val.isEmpty()) {
            password.setError("Veuillez indiquer un mot de passe !");
            return false;
        } else if(!val.matches(checkPassword)){
            password.setError("Le mot de passe doit contenir au moins 6 caractères et minimum 1 chiffre !");
            return false;
        } else {
            password.setError(null);
            password.setErrorEnabled(false);
            return true;
        }
    }



    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.connexion_btn:
                startActivity(new Intent(this, MainActivity.class));
                break;

        }
        switch (v.getId()) {
            case R.id.back_btn:
                startActivity(new Intent(this, StartUpScreen.class));
                break;

        }
        switch (v.getId()) {
            case R.id.banner_register:
                startActivity(new Intent(this, StartUpScreen.class));
                break;

        }


    }
}


